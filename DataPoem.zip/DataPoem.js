function custom1(){

    var a2=document.getElementById("red")
    a2.innerHTML="<fieldset class="+"b1"+"><fieldset class="+"a2"+"></fieldset><fieldset class="+"g1"+"> <strong class ="+"d1"+"></strong><br><br><br><form>@amyrobson<textarea class="+"i1"+" ></textarea></fieldset><fieldset class="+"a1"+"><center> &nbsp&nbsp &nbsp &nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp<input type="+"submit"+" value="+"reply"+" class="+"k1"+";></center></fieldset></fieldset></form>";
   
    

    
}
function custom2(){

    var a3=document.getElementById("red1")
    a3.innerHTML="<fieldset class="+"b1"+"><fieldset class="+"a2"+"></fieldset><fieldset class="+"g1"+"> <strong class ="+"d1"+"></strong><br><br><br><form>@maxblagun<textarea class="+"i1"+" ></textarea></fieldset><fieldset class="+"a1"+"><center> &nbsp&nbsp &nbsp &nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp<input type="+"submit"+" value="+"reply"+" class="+"k1"+";></center></fieldset></fieldset></form>";
   
    

    
}
function custom3(){

    var a3=document.getElementById("red3")
    a3.innerHTML="<fieldset class="+"b1"+"><fieldset class="+"a2"+"></fieldset><fieldset class="+"g1"+"> <strong class ="+"d1"+"></strong><br><br><br><form>@ramsesmiron<textarea class="+"i1"+" ></textarea></fieldset><fieldset class="+"a1"+"><center> &nbsp&nbsp &nbsp &nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp<input type="+"submit"+" value="+"reply"+" class="+"k1"+";></center></fieldset></fieldset></form>";
   
    

    
}
function custom4(){

    var a3=document.getElementById("red4")
    a3.innerHTML="<fieldset class="+"b1"+"><fieldset class="+"a2"+"></fieldset><fieldset class="+"g1"+"> <strong class ="+"d1"+"></strong><br><br><br><form><textarea class="+"i1"+" ></textarea></fieldset><fieldset class="+"a1"+"><center> &nbsp&nbsp &nbsp &nbsp &nbsp&nbsp&nbsp&nbsp &nbsp&nbsp<input type="+"submit"+" value="+"reply"+" class="+"k1"+";></center></fieldset></fieldset></form>";
   
    

    
}


function custom5(){
     var z =0;

    var a3=document.getElementById("red4")
    z++;
    a3.innerText=z;
   
    

    
}
function custom6(){
    

   var a3=document.getElementById("red4")
   var z1=0;
   a3.innerText=z1;
  
   

   
}



function must1(){
    var x1 =0;

   var m1=document.getElementById("blue1")
   x1++;
   m1.innerText=x1;
  
   

   
}
function must2(){
   

  var m2=document.getElementById("blue1")
  var x2=0;
  m2.innerText=x2;
 
  

  
}
function must3(){
   

    var m3=document.getElementById("blue3")
    var x3=0;
    x3++;
    m3.innerText=x3;
   
    
  
    
  }
  function must4(){
   

    var m4=document.getElementById("blue3")
    var x4=0;
    m4.innerText=x4;
   
    
  
    
  }
  function must5(){
   

    var m5=document.getElementById("blue5")
    var x5=0;
    x5++;
    m5.innerText=x5;
   
    
  
    
  }
  function must6(){
   

    var m6=document.getElementById("blue5")
    var x6=0;
    m6.innerText=x6;
   
    
  
    
  }